// JavaScript function to handle button clicks and navigation
function selectOption(option) {
    if (option === 'help') {
      window.location.href = "help.html";
    }
  }
  function selectOption1(option1) {
    if (option1 === 'simple intervention') {
      window.location.href = "simple intervention.html";
    }
  }
  function selectOption2(option2) {
    if (option2 === 'Urgent intervention') {
      window.location.href = "Urgent intervention.html";
    }
  }