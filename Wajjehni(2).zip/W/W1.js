 // JavaScript function to handle button clicks and navigation
 function selectOption(option) {
    if (option === 'event') {
      // Redirect to Campus Event page
      window.location.href = "W2.html";
    } else if (option === 'deals') {
      // Redirect to Campus Deals page
      window.location.href = "campus_deals.html";
    }
  }